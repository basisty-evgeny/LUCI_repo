---
name: Issue template
about: 'Create a issue to help us improve '

---

**Attention**
>You can know almost all useage and questions in the [WIKI](https://github.com/Jay-Goo/RangeSeekBar/wiki), please confirm you have read them before you question!

**Environment**
 - Device: [Google Pixel2]
 - OS: [6.0.1]
 - Library Version: [2.0.2]

**Description**
What's wrong with you ?

**Screenshots**
If applicable, add screenshots to help explain your problem.

**注意**
>你几乎可以从 [WIKI](https://github.com/Jay-Goo/RangeSeekBar/wiki)获取几乎所有的用法和常见问题, 在你提问之前请确认你已经看过以上内容!

**环境**
 - 设备: [Google Pixel2]
 - 系统: [6.0.1]
 - 库版本: [2.0.2]

**描述**

**截图**
