package com.aditya.filebrowser.interfaces;

/**
 * Created by Aditya on 4/15/2017.
 */
public interface ITrackSelection {
    boolean isSelected();
    void setSelected(boolean isSelected);
}
