package butterknife.internal;

public class Constants {

  private Constants() { }

  public static final int NO_RES_ID = -1;
}
