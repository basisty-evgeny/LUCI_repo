package com.example.butterknife;

public final class R {
  public static final class unsupported {
    public static int res = 0x7f040000;
  }

  public static final class anim {
    public static int res = 0x7f040001;
  }

  public static final class array {
    public static int res = 0x7f040002;
  }

  public static final class attr {
    public static int res = 0x7f040003;
  }

  public static final class bool {
    public static int res = 0x7f040004;
  }

  public static final class color {
    public static int res = 0x7f040005;
  }

  public static final class dimen {
    public static int res = 0x7f040006;
  }

  public static final class drawable {
    public static int res = 0x7f040007;
  }

  public static final class id {
    public static int res = 0x7f040008;
  }

  public static final class integer {
    public static int res = 0x7f040009;
  }

  public static final class layout {
    public static int res = 0x7f040010;
  }

  public static final class menu {
    public static int res = 0x7f040011;
  }

  public static final class plurals {
    public static int res = 0x7f040012;
  }

  public static final class string {
    public static int res = 0x7f040013;
  }

  public static final class style {
    public static int res = 0x7f040014;
  }

  public static final class styleable {
    public static int[] resArray = { 0x7f040003 };
    public static int res = 0x7f040015;
  }
}
