// Generated code from Butter Knife gradle plugin. Do not modify!
package com.butterknife.example;

import android.support.annotation.AnimRes;
import android.support.annotation.ArrayRes;
import android.support.annotation.AttrRes;
import android.support.annotation.BoolRes;
import android.support.annotation.ColorRes;
import android.support.annotation.DimenRes;
import android.support.annotation.DrawableRes;
import android.support.annotation.IdRes;
import android.support.annotation.IntegerRes;
import android.support.annotation.LayoutRes;
import android.support.annotation.MenuRes;
import android.support.annotation.PluralsRes;
import android.support.annotation.StringRes;
import android.support.annotation.StyleRes;
import android.support.annotation.StyleableRes;

public final class R2 {
  public static final class anim {
    @AnimRes
    public static final int res = 0x7f040001;
  }

  public static final class array {
    @ArrayRes
    public static final int res = 0x7f040002;
  }

  public static final class attr {
    @AttrRes
    public static final int res = 0x7f040003;
  }

  public static final class bool {
    @BoolRes
    public static final int res = 0x7f040004;
  }

  public static final class color {
    @ColorRes
    public static final int res = 0x7f040005;
  }

  public static final class dimen {
    @DimenRes
    public static final int res = 0x7f040006;
  }

  public static final class drawable {
    @DrawableRes
    public static final int res = 0x7f040007;
  }

  public static final class id {
    @IdRes
    public static final int res = 0x7f040008;
  }

  public static final class integer {
    @IntegerRes
    public static final int res = 0x7f040009;
  }

  public static final class layout {
    @LayoutRes
    public static final int res = 0x7f040010;
  }

  public static final class menu {
    @MenuRes
    public static final int res = 0x7f040011;
  }

  public static final class plurals {
    @PluralsRes
    public static final int res = 0x7f040012;
  }

  public static final class string {
    @StringRes
    public static final int res = 0x7f040013;
  }

  public static final class style {
    @StyleRes
    public static final int res = 0x7f040014;
  }

  public static final class styleable {
    @StyleableRes
    public static final int res = 0x7f040015;
  }
}
